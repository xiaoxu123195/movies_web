<?php
return array (
  'aa' => 
  array (
    'id' => 'aa',
    '__token__' => 'fe8550d97f1c838e5373527e89679bd5',
    'status' => '1',
    'name' => 'aa',
    'des' => '采集今日数据',
    'file' => 'collect',
    'param' => 'ac=cj&cjflag=b24c126793d9dbec81c9ca3a99bf41ba&cjurl=https%3A%2F%2Fapi.wujinapi.net%2Fapi.php%2Fprovide%2Fvod%2Ffrom%2Fwjm3u8%2F&h=24&t=&ids=&wd=&type=2&mid=1&opt=0&sync_pic_opt=0&filter=0&filter_from=&param=',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
    'runtime' => 1659150901,
  ),
  'bb' => 
  array (
    'id' => 'bb',
    '__token__' => '548d8d372ca6d3fbb8e35edffb06ac9d',
    'status' => '1',
    'name' => 'bb',
    'des' => '全网每日采集',
    'file' => 'collect',
    'param' => 'ac=cj&cjflag=3a4e1c6f613d66b5836bcbf23ce4c695&cjurl=http%3A%2F%2Fwww.zycaiji.net%3A7788%2Fapi.php%2Fprovide%2Fvod%2F%3Fac%3Dlist&h=24&t=&ids=&wd=&type=2&mid=1&opt=0&sync_pic_opt=0&filter=0&filter_from=&param=',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
    'runtime' => 1659152101,
  ),
  'cc' => 
  array (
    'id' => 'cc',
    '__token__' => '6c577d898a0f7054e546e8abfadc1683',
    'status' => '1',
    'name' => 'cc',
    'des' => '红牛',
    'file' => 'collect',
    'param' => 'ac=cj&cjflag=0388ded045382c5bf15ff53ec75d42c2&cjurl=https%3A%2F%2Fwww.hongniuzy2.com%2Fapi.php%2Fprovide%2Fvod%2Ffrom%2Fhnm3u8&h=24&t=&ids=&wd=&type=2&mid=1&opt=0&sync_pic_opt=0&filter=0&filter_from=&param=',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
    'runtime' => 1659151501,
  ),
  'dd' => 
  array (
    'id' => 'dd',
    '__token__' => '8e47e2af54b41b06961a3ae4e43ad658',
    'status' => '1',
    'name' => 'dd',
    'des' => '快播',
    'file' => 'collect',
    'param' => 'ac=cj&cjflag=b218dbd089fe71c6536cd0a17634ee9a&cjurl=http%3A%2F%2Fwww.kuaibozy.com%2Fapi.php%2Fprovide%2Fvod%2Ffrom%2Fkbm3u8%2Fat%2Fxml%2F&h=24&t=&ids=&wd=&type=1&mid=1&opt=0&sync_pic_opt=0&filter=0&filter_from=&param=',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
    'runtime' => 1659150301,
  ),
);