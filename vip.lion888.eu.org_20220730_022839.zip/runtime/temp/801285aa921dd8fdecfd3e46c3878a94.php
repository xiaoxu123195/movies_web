<?php if (!defined('THINK_PATH')) exit(); /*a:12:{s:33:"template/DYXS2/html/vod/type.html";i:1620142064;s:68:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/public/include.html";i:1622314980;s:66:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/public/head1.html";i:1622218346;s:64:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/vod/typetb.html";i:1617458888;s:64:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/vod/typeho.html";i:1617458888;s:67:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/public/vodbox.html";i:1620613830;s:64:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/vod/typefl.html";i:1617458888;s:64:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/vod/typedq.html";i:1617458888;s:67:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/public/paging.html";i:1620141904;s:65:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/public/foot.html";i:1621911972;s:69:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/public/tcnotice.html";i:1620625578;s:68:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/public/website.html";i:1621912062;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cn">
 <head>
     <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
     <title>最新<?php echo $obj['type_title']; ?>-推荐<?php echo $obj['type_title']; ?>-第<?php echo $param['page']; ?>页 - <?php echo $maccms['site_name']; ?></title>
    <meta name="keywords" content="<?php echo $obj['type_key']; ?>" />
    <meta name="description" content="<?php echo $obj['type_des']; ?>" />
     <?php $file = 'template/DYXS2/asset/admin/Dyxs2.php'; $newfile = 'application/admin/controller/Dyxs2.php'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $file = 'template/DYXS2/asset/admin/dyxsst.php'; $newfile = 'application/extra/dyxsst.php'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $file = 'template/DYXS2/asset/admin/dycms.html'; $newfile = 'application/admin/view/system/dycms.html'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $dyxsst = file_exists('application/extra/dyxsst.php') ? require('application/extra/dyxsst.php') : require(substr($maccms['path_tpl'], strlen($maccms['path'])).'asset/admin/dyxsst.php'); ?>

<link rel="icon" href="<?php echo mac_url_img($dyxsst['dycms']['s1']['logo2']); ?>" type="image/png" />
<link href="<?php echo $maccms['path_tpl']; ?>static/css/style.css" rel="stylesheet" type="text/css">
<link href="<?php echo $maccms['path_tpl']; ?>static/css/ali.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>static/css/swiper-bundle.min.css" type="text/css">
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.js"></script>
<script src="https://cdn.bootcdn.net/ajax/libs/layer/3.4.0/layer.min.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.lazyload.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.autocomplete.js"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.cookie.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/home.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.clipboard.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/swiper-bundle.min.js"></script>
<?php if($maccms['aid'] == 15): ?>
<script type="text/javascript">var vod_name='<?php echo $obj['vod_name']; ?>',vod_url=window.location.href,vod_part='<?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?>';</script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/history.js"></script>
 <script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.qrcode.min.js"></script>
<?php endif; ?>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/script.js"></script>

 </head>
 <body   class="page">
   <header id="header" class="wrapper">
	<div class="nav content">
		<div class="brand">
		<a href="<?php echo $maccms['path']; ?>" class="logo" title="<?php echo $maccms['site_url']; ?>&nbsp;-<?php echo $maccms['site_name']; ?>"><img src="<?php echo mac_url_img($dyxsst['dycms']['s1']['logo2']); ?>" alt="<?php echo $maccms['site_name']; ?>"></a>
		</div>
		<div class="nav-search">
			<form action="<?php echo mac_url('vod/search'); ?>">
				<div class="search-box">
					<input class="search-input ac_wd" id="txtKeywords" type="text" name="wd" autocomplete="off" placeholder="搜索电影、电视剧、综艺、动漫">
					<div class="search-drop">
						<div class="drop-content-items ac_hot none">
							<div class="list-item list-item-title"><strong>大家都在搜这些影片</strong></div>
							<div class="search-tag">
							<?php $_62e29c11cb3aa=explode(',',$maccms['search_hot']); if(is_array($_62e29c11cb3aa) || $_62e29c11cb3aa instanceof \think\Collection || $_62e29c11cb3aa instanceof \think\Paginator): if( count($_62e29c11cb3aa)==0 ) : echo "" ;else: foreach($_62e29c11cb3aa as $key2=>$vo2): ?>
					       	<a href="<?php echo mac_url('vod/search',['wd'=>$vo2]); ?>" class="<?php if($key2 < 4): ?>hot <?php else: endif; ?>"><i class="icon-hot"></i><?php echo $vo2; ?></a>
						    <?php endforeach; endif; else: echo "" ;endif; ?>
							</div>
						</div>
					</div>
					<button class="search-btn search-go" type="submit"><i class="icon-search"></i></button>
					<button class="cancel-btn" type="button">取消</button>
				</div>
			</form>
		</div>
		<nav class="nav-menu">
			<ul class="nav-menu-items">
				<li class="nav-menu-item <?php if($maccms['aid'] == 1): ?>selected<?php endif; ?>">
					<a href="<?php echo $maccms['path']; ?>" class="white " title="<?php echo $maccms['site_name']; ?>首页"><i class="icon-home"></i>首页</a>
				</li>
				 <?php $__TAG__ = '{"num":"4","order":"asc","by":"sort","ids":"parent","flag":"vod","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>			
				<li class="nav-menu-item <?php if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?>selected<?php endif; ?>">
					<a class="nav-link white" href="<?php echo mac_url_type($vo); ?>">
							<?php if(stristr($vo['type_name'],'纪录片')==true||stristr($vo['parent']['type_name'],'纪录片')==true): ?><i class="iconfont icon-zhibo"></i><?php elseif(stristr($vo['type_name'],'直播')==true||stristr($vo['parent']['type_name'],'直播')==true): ?><i class="iconfont icon-qiepian"></i><?php elseif(stristr($vo['type_name'],'美剧')==true||stristr($vo['parent']['type_name'],'美剧')==true): ?><i class="iconfont icon-qita"></i><?php else: if($vo['type_id'] == 1): ?>
	                        <i class="icon-cate-dy"></i>
	                        <?php elseif($vo['type_id'] == 2): ?>
	                        <i class="icon-cate-ds"></i>
	                        <?php elseif($vo['type_id'] == 4): ?>
	                        <i class="icon-cate-dm"></i>
	                        <?php else: ?>
	                        <i class="icon-cate-zy"></i>
	                        <?php endif; endif; ?>
					<?php echo $vo['type_name']; ?> </a>
				</li>
				<?php endforeach; endif; else: echo "" ;endif; if($dyxsst['dycms']['s2']['diy1'] == 1): ?>
					<li class="nav-menu-item">
					<a href="<?php echo $dyxsst['dycms']['s2']['diy1url']; ?>" class="white " ><i class="icon-more"></i>&nbsp;<?php echo $dyxsst['dycms']['s2']['diy1name']; ?></a>
				</li>
				<?php endif; if($dyxsst['dycms']['s2']['diy2'] == 1): ?>
					<li class="nav-menu-item">
					<a href="<?php echo $dyxsst['dycms']['s2']['diy2url']; ?>" class="white " ><i class="icon-more"></i>&nbsp;<?php echo $dyxsst['dycms']['s2']['diy2name']; ?></a>
				</li>
				<?php endif; if($dyxsst['dycms']['s2']['wz'] == 1): ?>
				<li class="nav-menu-item domain white "><i class="icon-domain"></i>网址<em>+</em></li>
				<?php endif; ?>
				<li class="space-line-bold white "></li>
				<li class="nav-menu-item drop">
					<span class="nav-menu-icon">
                        <i class="icon-watch-history  white "></i>
                    </span>
					<div class="drop-content drop-history">
						<div class="drop-content-box">
							<ul class="drop-content-items" id="history">
								<li class="list-item list-item-title">
									<a href="" class="playlist historyclean">
										<i class="icon-clear"></i>
									</a>
									<strong>我的观影记录</strong>
								</li>
							</ul>
						</div>
					</div>
					<div class="shortcuts-mobile-overlay"></div>
				</li>
				<li class="space-line-bold"></li>
				<li class="nav-menu-item drop">
					<span class="nav-menu-icon">
                        <i class="icon-all" style="color: #fff;"></i>
                    </span>
					<div class="drop-content sub-block">
						<div class="drop-content-box grid-box">
							<ul class="drop-content-items grid-items">
								<li class="grid-item">
									<a href="<?php echo $maccms['path']; ?>">
										<i class="icon-home"></i>
										<div class="grid-item-name" title="<?php echo $maccms['site_name']; ?>首页">首页</div>
									</a>
								</li>
							 <?php $__TAG__ = '{"order":"asc","by":"sort","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>			
								<li  class="grid-item">
									<a href="<?php echo mac_url_type($vo); ?>" title="<?php echo $vo['type_name']; ?>">
							<?php if(stristr($vo['type_name'],'纪录片')==true||stristr($vo['parent']['type_name'],'纪录片')==true): ?><i class="iconfont icon-zhibo"></i><?php elseif(stristr($vo['type_name'],'直播')==true||stristr($vo['parent']['type_name'],'直播')==true): ?><i class="iconfont icon-qiepian"></i><?php elseif(stristr($vo['type_name'],'美剧')==true||stristr($vo['parent']['type_name'],'美剧')==true): ?><i class="iconfont icon-qita"></i><?php else: ?>									    
										<i class="<?php switch($vo['type_id']): case "1": ?>icon-cate-dy<?php break; case "2": ?>icon-cate-ds<?php break; case "3": ?>icon-cate-zy<?php break; case "4": ?>icon-cate-dm<?php break; case "5": ?>iconfont icon-zixun<?php break; ?>{/case}<?php default: ?>icon-zixun<?php endswitch; ?>"></i><?php endif; ?>
										<div class="grid-item-name"><?php echo $vo['type_name']; ?></div>
									</a>
								</li>
								<?php endforeach; endif; else: echo "" ;endif; if($dyxsst['dycms']['s2']['wz'] == 1): ?>
								<li class="grid-item">
								<a href="<?php echo mac_url('label/web'); ?>"><i class="icon-domain"></i>
								<div class="grid-item-name" title="网址">网址</div>
								</a>
								</li>
								<?php endif; if($dyxsst['dycms']['s2']['topic'] == 1): ?>
								<li class="grid-item">
								<a href="<?php echo mac_url('topic/index'); ?>"><i class="iconfont icon-zhuanxiangxinxi"></i>
								<div class="grid-item-name" title="专题">专题</div>
								</a>
								</li>
								<?php endif; ?>
								<li class="grid-item grid-more">
									<a class="grid-more-link"  href="<?php echo mac_url_type($obj,['id'=>1],'show'); ?>" title="查看全部影片">
										<div class="grid-item-name">全部影片</div>
									</a>
								</li>
								<?php if($dyxsst['dycms']['s2']['app'] == 1): ?>
							    <li class="grid-item grid-more android">
								<a href="<?php echo mac_url('label/app'); ?>" class="grid-more-link" title="下载<?php echo $maccms['site_name']; ?>APP">
								<div class="grid-item-name">下载客户端</div>
								</a>
								</li>
								<?php endif; ?>
							</ul>
						</div>
					</div>
					<div class="shortcuts-mobile-overlay"></div>
				</li>
				<?php if($dyxsst['dycms']['s2']['user'] == 1): ?>
				<li class="space-line-bold"></li>
				<li class="nav-menu-item drop">
				<?php if($user['group']['group_id'] == 1): ?>
				<a href="<?php echo mac_url('user/login'); ?>" class=" white " title="用户登录"><i class="iconfont icon-yonghu"></i></a>
				<?php else: ?>
				<a href="<?php echo mac_url('user/index'); ?>" class=" white " title="个人中心"><i class="iconfont icon-yonghu"></i></a>				
				</li>
				<?php endif; endif; ?>
			</ul>
		</nav>
	</div>
</header>   <!-- 头部 -->
   <main id="main" class="wrapper">
  <div class="content">
                <div class="page-heading">
      <h1 class="page-title"><?php echo $obj['type_name']; ?></h1>
      <div class="list-header scroll-box">
        <div class="block-box-items scroll-content">
       <?php if($obj['childids']||$obj['parent']['childids']): if($obj['type_pid'] == 0): $__TAG__ = '{"parent":"'.$obj['type_id'].'","order":"asc","by":"sort","id":"vo2","key":"key2"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key2 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo2): $mod = ($key2 % 2 );++$key2;?>
          <div class="block-box-item <?php if($vo2['type_id'] == $obj['type_id']): ?>selected<?php endif; ?>">
            <a class="block-box-content" href="<?php echo mac_url_type($vo2,[],'type'); ?>"  title="<?php echo $vo2['type_name']; ?>"><strong class="title"><?php echo $vo2['type_name']; ?></strong></a>
            <div class="block-box-bg"><?php echo $vo2['type_name']; ?></div>
          </div>
          	<?php endforeach; endif; else: echo "" ;endif; else: $__TAG__ = '{"parent":"'.$obj['type_pid'].'","order":"asc","by":"sort","id":"vo2","key":"key2"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key2 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo2): $mod = ($key2 % 2 );++$key2;?>
          <div class="block-box-item <?php if($vo2['type_id'] == $obj['type_id']): ?>selected<?php endif; ?>">
            <a class="block-box-content" href="<?php echo mac_url_type($vo2,[],'type'); ?>"  title="<?php echo $vo2['type_name']; ?>"><strong class="title"><?php echo $vo2['type_name']; ?></strong></a>
            <div class="block-box-bg"><?php echo $vo2['type_name']; ?></div>
          </div>
          	<?php endforeach; endif; else: echo "" ;endif; endif; else: $_62e29c11cb1b9=explode(',',$obj['type_extend']['area']); if(is_array($_62e29c11cb1b9) || $_62e29c11cb1b9 instanceof \think\Collection || $_62e29c11cb1b9 instanceof \think\Paginator): if( count($_62e29c11cb1b9)==0 ) : echo "" ;else: foreach($_62e29c11cb1b9 as $key1=>$vo1): ?> 
          <div class="block-box-item">
            <a class="block-box-content" href="<?php echo mac_url_type($obj,['area'=>$vo1],'show'); ?>"  title="<?php echo $vo1; ?><?php echo $obj['type_name']; ?>"><strong class="title"><?php echo $vo1; ?><?php echo $obj['type_name']; ?></strong></a>
            <div class="block-box-bg"><?php echo $vo1; ?><?php echo $obj['type_name']; ?></div>
          </div>
           <?php endforeach; endif; else: echo "" ;endif; endif; ?>
           <div class="space-line-bold"></div>
          <div class="block-box-item"><a class="block-box-content" href="<?php echo mac_url_type($obj,[],'show'); ?>" title="查看全部影片"><strong class="title">影片库</strong></a>
            <div class="block-box-bg"><i class="icon-cate-dy"></i></div>
          </div>
        </div>
      </div>
    </div>
     <!-- 分类页分类 -->
    
            <?php if($obj['type_extend']['area']): ?>
         <div class="module module-bg">
      <div class="module-heading">
        <h2 class="module-title">热播<?php echo $obj['type_name']; ?></h2>
      </div>
      <div class="module-list module-lines-list">
        <div class="module-items">
         <?php $__TAG__ = '{"num":"16","type":"current","order":"desc","by":"hits","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>  
	                    <div class="module-item">
				<div class="module-item-cover">
					<div class="module-item-pic">
						<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>" >
							<i class="icon-play"></i>
						</a>
						<img class="lazy lazyloaded"  data-src="<?php echo mac_url_img($vo['vod_pic']); ?>" src="<?php echo mac_url_img($dyxsst['dycms']['s1']['pic']); ?>"  alt="<?php echo $vo['vod_name']; ?>">
						<div class="loading"></div>
					</div>
					<div class="module-item-caption">
						<span><?php echo $vo['vod_year']; ?></span>
						<span class="video-class"><?php echo $vo['type']['type_name']; ?></span>
						<span><?php echo $vo['vod_area']; ?></span>
					</div>
					<div class="module-item-content">
						<div class="module-item-style video-name">
							<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
						</div>
						<div class="module-item-style video-tag">
						<?php echo mac_url_create(mac_default($vo['vod_actor'],'未知'),'actor'); ?>
						</div>
						<div class="module-item-style video-text"><?php echo $vo['vod_blurb']; ?></div>
					</div>
				</div>
				<div class="module-item-titlebox">
					<a href="<?php echo mac_url_vod_detail($vo); ?>" class="module-item-title" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
				</div>
				<div class="module-item-text"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></div>
			</div>
		<?php endforeach; endif; else: echo "" ;endif; ?>     
       </div>
      </div>
    </div>
    <?php endif; ?>  <!-- 分类页热播 -->
        
       	<?php if(!$obj['childids'] == ''): $__TAG__ = '{"parent":"current","order":"asc","by":"sort","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
        <div class="module module-bg">
      <div class="module-heading">
        <h2 class="module-title"><a href="<?php echo mac_url_type($vo,[],'type'); ?>" title="<?php echo $vo['type_name']; ?>"><?php echo $vo['type_name']; ?></a></h2>
        <a class="more" href="<?php echo mac_url_type($vo,[],'type'); ?>" title="更多<?php echo $vo1['type_name']; ?>">更多<?php echo $vo['type_name']; ?><i class="icon-arrow-right-o"></i></a></div>
      <div class="module-list module-line-list">
        <div class="module-items">
        <?php $__TAG__ = '{"num":"32","type":"'.$vo['type_id'].'","order":"desc","by":"time","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
	                    <div class="module-item">
				<div class="module-item-cover">
					<div class="module-item-pic">
						<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>" >
							<i class="icon-play"></i>
						</a>
						<img class="lazy lazyloaded"  data-src="<?php echo mac_url_img($vo['vod_pic']); ?>" src="<?php echo mac_url_img($dyxsst['dycms']['s1']['pic']); ?>"  alt="<?php echo $vo['vod_name']; ?>">
						<div class="loading"></div>
					</div>
					<div class="module-item-caption">
						<span><?php echo $vo['vod_year']; ?></span>
						<span class="video-class"><?php echo $vo['type']['type_name']; ?></span>
						<span><?php echo $vo['vod_area']; ?></span>
					</div>
					<div class="module-item-content">
						<div class="module-item-style video-name">
							<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
						</div>
						<div class="module-item-style video-tag">
						<?php echo mac_url_create(mac_default($vo['vod_actor'],'未知'),'actor'); ?>
						</div>
						<div class="module-item-style video-text"><?php echo $vo['vod_blurb']; ?></div>
					</div>
				</div>
				<div class="module-item-titlebox">
					<a href="<?php echo mac_url_vod_detail($vo); ?>" class="module-item-title" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
				</div>
				<div class="module-item-text"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></div>
			</div>
		<?php endforeach; endif; else: echo "" ;endif; ?>        
          </div>
      </div>
    </div>
     <?php endforeach; endif; else: echo "" ;endif; ?>  <!-- 有二级分类 -->
        
	    <?php else: $_62e29c11caff6=explode(',',$obj['type_extend']['area']); if(is_array($_62e29c11caff6) || $_62e29c11caff6 instanceof \think\Collection || $_62e29c11caff6 instanceof \think\Paginator): if( count($_62e29c11caff6)==0 ) : echo "" ;else: foreach($_62e29c11caff6 as $key1=>$vo1): ?> 			
        <div class="module module-bg">
      <div class="module-heading">
        <h2 class="module-title"><?php if($vo1 == $param['area']): ?><?php echo mac_data_count($obj['type_id'],'all'); ?>部<?php endif; ?><?php echo $vo1; ?><?php echo $obj['type_name']; ?></h2>
      </div>
      <div class="module-list  <?php if($obj['type_extend']['area']): ?>module-line-list<?php endif; ?>">
        <div class="module-items">
     <?php $__TAG__ = '{"num":"72","type":"current","area":"'.$vo1.'","order":"desc","by":"time","paging":"yes","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__);$__PAGING__ = mac_page_param($__LIST__['total'],$__LIST__['limit'],$__LIST__['page'],$__LIST__['pageurl'],$__LIST__['half']); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>		
	                    <div class="module-item">
				<div class="module-item-cover">
					<div class="module-item-pic">
						<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>" >
							<i class="icon-play"></i>
						</a>
						<img class="lazy lazyloaded"  data-src="<?php echo mac_url_img($vo['vod_pic']); ?>" src="<?php echo mac_url_img($dyxsst['dycms']['s1']['pic']); ?>"  alt="<?php echo $vo['vod_name']; ?>">
						<div class="loading"></div>
					</div>
					<div class="module-item-caption">
						<span><?php echo $vo['vod_year']; ?></span>
						<span class="video-class"><?php echo $vo['type']['type_name']; ?></span>
						<span><?php echo $vo['vod_area']; ?></span>
					</div>
					<div class="module-item-content">
						<div class="module-item-style video-name">
							<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
						</div>
						<div class="module-item-style video-tag">
						<?php echo mac_url_create(mac_default($vo['vod_actor'],'未知'),'actor'); ?>
						</div>
						<div class="module-item-style video-text"><?php echo $vo['vod_blurb']; ?></div>
					</div>
				</div>
				<div class="module-item-titlebox">
					<a href="<?php echo mac_url_vod_detail($vo); ?>" class="module-item-title" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
				</div>
				<div class="module-item-text"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></div>
			</div>
		<?php endforeach; endif; else: echo "" ;endif; ?>        
          </div>
      </div>
    </div>
     <?php endforeach; endif; else: echo "" ;endif; ?>    <!-- 无二级分类显示地区 -->
        
         <?php if($__PAGING__['page_total'] > 1): ?>
<div class="module-footer">
      <div id="page">
        <a href="<?php echo mac_url_page($__PAGING__['page_url'],1); ?>" class="page-number page-previous" title="首页">首页</a>
        <a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_prev']); ?>" class="page-number page-previous" title="上一页">上一页</a>
        <?php if(is_array($__PAGING__['page_num']) || $__PAGING__['page_num'] instanceof \think\Collection || $__PAGING__['page_num'] instanceof \think\Paginator): if( count($__PAGING__['page_num'])==0 ) : echo "" ;else: foreach($__PAGING__['page_num'] as $key=>$num): if($__PAGING__['page_current'] == $num): ?>
        <span class="page-number page-current display"><?php echo $num; ?></span>
        <?php else: ?>
          <a href="<?php echo mac_url_page($__PAGING__['page_url'],$num); ?>" class="page-number display" title="第<?php echo $num; ?>页"><?php echo $num; ?></a>
            <?php endif; endforeach; endif; else: echo "" ;endif; ?>
           <a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_next']); ?>" class="page-number page-next" title="下一页">下一页</a>
        <a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_total']); ?>" class="page-number page-next" title="尾页">尾页</a>
      </div>
    </div>
<?php endif; ?>  <!-- 分页 -->
         
       <?php endif; ?>   
    </div>
    
    <div class="module-footer module-type">
    <a href="<?php echo mac_url_type($obj,[],'show'); ?>" class="load-all" title="全部<?php echo $obj['type_name']; ?>">全部<?php echo $obj['type_name']; ?><i class="icon-arrow-right-o"></i></a>
    </div>
</main>
    <footer id="footer" class="wrapper">
	<p class="sitemap">
	    <?php if($dyxsst['dycms']['s2']['about'] == 1): ?>
		<a target="_blank" href="<?php echo mac_url('label/about'); ?>">关于</a><span class="space-line-bold"></span>
		<?php endif; ?>
		<a target="_blank" href="<?php echo mac_url('map/index'); ?>">MAP</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/index'); ?>">RSS</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/baidu'); ?>">Baidu</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/baidu'); ?>">Google</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/bing'); ?>">Bing</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/so'); ?>">so</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/sogou'); ?>">Sogou</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/sm'); ?>">SM</a>
	</p>
	<p><?php echo $dyxsst['dycms']['s1']['sm']; ?></p>
	<p class="none"><?php echo $maccms['site_tj']; ?></p>
</footer>



<div class="foot_right_bar">
	<div title="求片留言">
	<a  href="<?php echo mac_url('gbook/index'); ?>" >
	<i class="iconfont icon-liuyan"></i>
	</a>
	</div>
	<div class="goTop" title="返回顶部">
		<i class="iconfont icon-up"></i>
	</div>
</div>

<script type="text/javascript">
$(function(){	
	$(window).scroll(function() {		
		if($(window).scrollTop() >= 100){
			$('.goTop').fadeIn(300); 
		}else{    
			$('.goTop').fadeOut(300);    
		}  
	});
	$('.goTop').click(function(){
	$('html,body').animate({scrollTop: '0px'}, 800);});	
});
</script>

<?php if($dyxsst['dycms']['s2']['tc'] == 1): ?>

<div class="popup" id="note" style="display:none;">
	<div class="popup-icon"><img src="<?php echo $maccms['path_tpl']; ?>static/picture/backhome.svg"></div>
	<div class="popup-header">
		<h3 class="popup-title">公告内容</h3>
	</div>
	<div class="popup-main">
<?php echo $dyxsst['dycms']['s2']['tc_noti']; ?>
	</div>
	<div class="popup-footer"><span class="popup-btn" onclick="closeclick()">我记住啦</span></div>
</div>
<?php endif; ?>
<script src="<?php echo $maccms['path_tpl']; ?>static/js/tccookie.js"></script>
 <!-- 弹窗公告-->

   
<div class="popup popup-notice none">
	<div class="popup-icon"><img src="<?php echo $maccms['path_tpl']; ?>static/picture/backhome.svg"></div>
	<div class="popup-header">
		<h3 class="popup-title">域名列表</h3></div>
	<div class="popup-main">
		<p>本站有多个域名方便大家记住可以上哦!</p>
		<p>-
			<a><strong><?php echo $maccms['site_url']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web1']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web2']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web3']; ?></strong></a><br>
		</p>
	</div>
	<div class="popup-footer">
		<a href="<?php echo mac_url('label/web'); ?>" class="popup-btn-o">查看全部域名</a>
		<?php if($dyxsst['dycms']['s2']['about'] == 1): ?>
		<a href="<?php echo mac_url('label/about'); ?>" class="popup-btn-o">关于本站</a>
		<?php endif; ?>
	</div>
	<div class="close-popup" id="close-popup"><i class="icon-close-o"></i></div>
</div> <!-- 网址-->
         
<div class="shortcuts-mobile-overlay"></div>
 <!-- 底部-->
 </body>
</html>