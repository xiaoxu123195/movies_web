<?php if (!defined('THINK_PATH')) exit(); /*a:11:{s:33:"template/DYXS2/html/vod/play.html";i:1651478188;s:68:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/public/include.html";i:1622314980;s:66:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/public/head1.html";i:1622218346;s:62:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/vod/like.html";i:1620142612;s:67:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/public/vodbox.html";i:1620613830;s:61:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/vod/hot.html";i:1620172790;s:65:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/public/foot.html";i:1621911972;s:69:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/public/tcnotice.html";i:1620625578;s:68:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/public/website.html";i:1621912062;s:68:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/vod/projection.html";i:1620142732;s:64:"/www/wwwroot/vip.kejilion.tk/template/DYXS2/html/vod/report.html";i:1620142748;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <title>在线播放<?php echo $obj['vod_name']; ?> <?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?> -<?php echo $maccms['site_name']; ?></title>
    <meta name="keywords" content="<?php echo $obj['vod_name']; ?><?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?>免费在线观看,<?php echo $obj['vod_name']; ?>剧情介绍" />
    <meta name="description" content="<?php echo $obj['vod_name']; ?><?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?>免费在线观看,<?php echo $obj['vod_name']; ?>剧情介绍" />
<?php $file = 'template/DYXS2/asset/admin/Dyxs2.php'; $newfile = 'application/admin/controller/Dyxs2.php'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $file = 'template/DYXS2/asset/admin/dyxsst.php'; $newfile = 'application/extra/dyxsst.php'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $file = 'template/DYXS2/asset/admin/dycms.html'; $newfile = 'application/admin/view/system/dycms.html'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $dyxsst = file_exists('application/extra/dyxsst.php') ? require('application/extra/dyxsst.php') : require(substr($maccms['path_tpl'], strlen($maccms['path'])).'asset/admin/dyxsst.php'); ?>

<link rel="icon" href="<?php echo mac_url_img($dyxsst['dycms']['s1']['logo2']); ?>" type="image/png" />
<link href="<?php echo $maccms['path_tpl']; ?>static/css/style.css" rel="stylesheet" type="text/css">
<link href="<?php echo $maccms['path_tpl']; ?>static/css/ali.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>static/css/swiper-bundle.min.css" type="text/css">
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.js"></script>
<script src="https://cdn.bootcdn.net/ajax/libs/layer/3.4.0/layer.min.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.lazyload.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.autocomplete.js"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.cookie.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/home.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.clipboard.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/swiper-bundle.min.js"></script>
<?php if($maccms['aid'] == 15): ?>
<script type="text/javascript">var vod_name='<?php echo $obj['vod_name']; ?>',vod_url=window.location.href,vod_part='<?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?>';</script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/history.js"></script>
 <script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.qrcode.min.js"></script>
<?php endif; ?>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/script.js"></script>
   <!-- 头部 -->
</head>
<body  class="page play">
 <header id="header" class="wrapper">
	<div class="nav content">
		<div class="brand">
		<a href="<?php echo $maccms['path']; ?>" class="logo" title="<?php echo $maccms['site_url']; ?>&nbsp;-<?php echo $maccms['site_name']; ?>"><img src="<?php echo mac_url_img($dyxsst['dycms']['s1']['logo2']); ?>" alt="<?php echo $maccms['site_name']; ?>"></a>
		</div>
		<div class="nav-search">
			<form action="<?php echo mac_url('vod/search'); ?>">
				<div class="search-box">
					<input class="search-input ac_wd" id="txtKeywords" type="text" name="wd" autocomplete="off" placeholder="搜索电影、电视剧、综艺、动漫">
					<div class="search-drop">
						<div class="drop-content-items ac_hot none">
							<div class="list-item list-item-title"><strong>大家都在搜这些影片</strong></div>
							<div class="search-tag">
							<?php $_62e29b9f8cde8=explode(',',$maccms['search_hot']); if(is_array($_62e29b9f8cde8) || $_62e29b9f8cde8 instanceof \think\Collection || $_62e29b9f8cde8 instanceof \think\Paginator): if( count($_62e29b9f8cde8)==0 ) : echo "" ;else: foreach($_62e29b9f8cde8 as $key2=>$vo2): ?>
					       	<a href="<?php echo mac_url('vod/search',['wd'=>$vo2]); ?>" class="<?php if($key2 < 4): ?>hot <?php else: endif; ?>"><i class="icon-hot"></i><?php echo $vo2; ?></a>
						    <?php endforeach; endif; else: echo "" ;endif; ?>
							</div>
						</div>
					</div>
					<button class="search-btn search-go" type="submit"><i class="icon-search"></i></button>
					<button class="cancel-btn" type="button">取消</button>
				</div>
			</form>
		</div>
		<nav class="nav-menu">
			<ul class="nav-menu-items">
				<li class="nav-menu-item <?php if($maccms['aid'] == 1): ?>selected<?php endif; ?>">
					<a href="<?php echo $maccms['path']; ?>" class="white " title="<?php echo $maccms['site_name']; ?>首页"><i class="icon-home"></i>首页</a>
				</li>
				 <?php $__TAG__ = '{"num":"4","order":"asc","by":"sort","ids":"parent","flag":"vod","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>			
				<li class="nav-menu-item <?php if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?>selected<?php endif; ?>">
					<a class="nav-link white" href="<?php echo mac_url_type($vo); ?>">
							<?php if(stristr($vo['type_name'],'纪录片')==true||stristr($vo['parent']['type_name'],'纪录片')==true): ?><i class="iconfont icon-zhibo"></i><?php elseif(stristr($vo['type_name'],'直播')==true||stristr($vo['parent']['type_name'],'直播')==true): ?><i class="iconfont icon-qiepian"></i><?php elseif(stristr($vo['type_name'],'美剧')==true||stristr($vo['parent']['type_name'],'美剧')==true): ?><i class="iconfont icon-qita"></i><?php else: if($vo['type_id'] == 1): ?>
	                        <i class="icon-cate-dy"></i>
	                        <?php elseif($vo['type_id'] == 2): ?>
	                        <i class="icon-cate-ds"></i>
	                        <?php elseif($vo['type_id'] == 4): ?>
	                        <i class="icon-cate-dm"></i>
	                        <?php else: ?>
	                        <i class="icon-cate-zy"></i>
	                        <?php endif; endif; ?>
					<?php echo $vo['type_name']; ?> </a>
				</li>
				<?php endforeach; endif; else: echo "" ;endif; if($dyxsst['dycms']['s2']['diy1'] == 1): ?>
					<li class="nav-menu-item">
					<a href="<?php echo $dyxsst['dycms']['s2']['diy1url']; ?>" class="white " ><i class="icon-more"></i>&nbsp;<?php echo $dyxsst['dycms']['s2']['diy1name']; ?></a>
				</li>
				<?php endif; if($dyxsst['dycms']['s2']['diy2'] == 1): ?>
					<li class="nav-menu-item">
					<a href="<?php echo $dyxsst['dycms']['s2']['diy2url']; ?>" class="white " ><i class="icon-more"></i>&nbsp;<?php echo $dyxsst['dycms']['s2']['diy2name']; ?></a>
				</li>
				<?php endif; if($dyxsst['dycms']['s2']['wz'] == 1): ?>
				<li class="nav-menu-item domain white "><i class="icon-domain"></i>网址<em>+</em></li>
				<?php endif; ?>
				<li class="space-line-bold white "></li>
				<li class="nav-menu-item drop">
					<span class="nav-menu-icon">
                        <i class="icon-watch-history  white "></i>
                    </span>
					<div class="drop-content drop-history">
						<div class="drop-content-box">
							<ul class="drop-content-items" id="history">
								<li class="list-item list-item-title">
									<a href="" class="playlist historyclean">
										<i class="icon-clear"></i>
									</a>
									<strong>我的观影记录</strong>
								</li>
							</ul>
						</div>
					</div>
					<div class="shortcuts-mobile-overlay"></div>
				</li>
				<li class="space-line-bold"></li>
				<li class="nav-menu-item drop">
					<span class="nav-menu-icon">
                        <i class="icon-all" style="color: #fff;"></i>
                    </span>
					<div class="drop-content sub-block">
						<div class="drop-content-box grid-box">
							<ul class="drop-content-items grid-items">
								<li class="grid-item">
									<a href="<?php echo $maccms['path']; ?>">
										<i class="icon-home"></i>
										<div class="grid-item-name" title="<?php echo $maccms['site_name']; ?>首页">首页</div>
									</a>
								</li>
							 <?php $__TAG__ = '{"order":"asc","by":"sort","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>			
								<li  class="grid-item">
									<a href="<?php echo mac_url_type($vo); ?>" title="<?php echo $vo['type_name']; ?>">
							<?php if(stristr($vo['type_name'],'纪录片')==true||stristr($vo['parent']['type_name'],'纪录片')==true): ?><i class="iconfont icon-zhibo"></i><?php elseif(stristr($vo['type_name'],'直播')==true||stristr($vo['parent']['type_name'],'直播')==true): ?><i class="iconfont icon-qiepian"></i><?php elseif(stristr($vo['type_name'],'美剧')==true||stristr($vo['parent']['type_name'],'美剧')==true): ?><i class="iconfont icon-qita"></i><?php else: ?>									    
										<i class="<?php switch($vo['type_id']): case "1": ?>icon-cate-dy<?php break; case "2": ?>icon-cate-ds<?php break; case "3": ?>icon-cate-zy<?php break; case "4": ?>icon-cate-dm<?php break; case "5": ?>iconfont icon-zixun<?php break; ?>{/case}<?php default: ?>icon-zixun<?php endswitch; ?>"></i><?php endif; ?>
										<div class="grid-item-name"><?php echo $vo['type_name']; ?></div>
									</a>
								</li>
								<?php endforeach; endif; else: echo "" ;endif; if($dyxsst['dycms']['s2']['wz'] == 1): ?>
								<li class="grid-item">
								<a href="<?php echo mac_url('label/web'); ?>"><i class="icon-domain"></i>
								<div class="grid-item-name" title="网址">网址</div>
								</a>
								</li>
								<?php endif; if($dyxsst['dycms']['s2']['topic'] == 1): ?>
								<li class="grid-item">
								<a href="<?php echo mac_url('topic/index'); ?>"><i class="iconfont icon-zhuanxiangxinxi"></i>
								<div class="grid-item-name" title="专题">专题</div>
								</a>
								</li>
								<?php endif; ?>
								<li class="grid-item grid-more">
									<a class="grid-more-link"  href="<?php echo mac_url_type($obj,['id'=>1],'show'); ?>" title="查看全部影片">
										<div class="grid-item-name">全部影片</div>
									</a>
								</li>
								<?php if($dyxsst['dycms']['s2']['app'] == 1): ?>
							    <li class="grid-item grid-more android">
								<a href="<?php echo mac_url('label/app'); ?>" class="grid-more-link" title="下载<?php echo $maccms['site_name']; ?>APP">
								<div class="grid-item-name">下载客户端</div>
								</a>
								</li>
								<?php endif; ?>
							</ul>
						</div>
					</div>
					<div class="shortcuts-mobile-overlay"></div>
				</li>
				<?php if($dyxsst['dycms']['s2']['user'] == 1): ?>
				<li class="space-line-bold"></li>
				<li class="nav-menu-item drop">
				<?php if($user['group']['group_id'] == 1): ?>
				<a href="<?php echo mac_url('user/login'); ?>" class=" white " title="用户登录"><i class="iconfont icon-yonghu"></i></a>
				<?php else: ?>
				<a href="<?php echo mac_url('user/index'); ?>" class=" white " title="个人中心"><i class="iconfont icon-yonghu"></i></a>				
				</li>
				<?php endif; endif; ?>
			</ul>
		</nav>
	</div>
</header>   <!-- 头部 -->
<main id="main" class="wrapper">
  <div class="player-block">
    <div class="content">
      <div class="player-box">
        <div class="player-box-main">
          <div class=""><span class=""><i class=""></i></span>
            <ul class="tips-list">
              <div class="swiper-container">
                <div class="swiper-wrapper">
            </div></div>
            </ul>
          </div>
          <div class="player-wrapper"><?php echo $player_data; ?><?php echo $player_js; ?>
                    
			        <div class="player-box-switch">
						<span class="btn_switch_bg">
							<svg class="svg_icon" viewBox="0 0 9 59" width="9" height="59"><path d="M3.8,5.1C1.7,4.3,0.2,2.4,0,0h0v5v4v41v5v3.9c0.6-1.9,2.1-3.4,4-4v0c2.9-0.7,5-3.2,5-6.3v-37  C9,8.4,6.8,5.7,3.8,5.1z"></path></svg>
						</span>
						<i class="icon-arrow-left-o"></i>
						<i class="icon-arrow-right-o"></i>
    				</div>  
          </div>
        </div>
      </div>
      <div class="player-info">
        <div class="video-info">
          <div class="video-info-box">
            <div class="video-info-header">
              <h1 class="page-title"><a href="<?php echo mac_url_vod_detail($obj); ?>" title="<?php echo $obj['vod_name']; ?>"><?php echo $obj['vod_name']; ?></a></h1>
              <span class="btn-pc page-title"><?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?></span>
              <div class="video-info-aux">
                <a href="<?php if($obj['type_1']!=''): ?><?php echo mac_url_type($obj['type_1']); else: ?><?php echo mac_url_type($obj['type']); endif; ?>" title="<?php if($obj['type_1']!=''): ?><?php echo $obj['type_1']['type_name']; else: ?><?php echo $obj['type']['type_name']; endif; ?>" class="tag-link">
                <span class="video-tag-icon">
                    <?php if($obj['type_id_1'] == 1||$obj['type_id'] == 1): ?>
                     <i class="icon-cate-dy"></i>
                     <?php elseif($obj['type_id_1'] == 2||$obj['type_id'] == 2): ?>
                     <i class="icon-cate-ds"></i>
                     <?php elseif($obj['type_id_1'] == 3||$obj['type_id'] == 3): ?>
                     <i class="icon-cate-zy"></i>
                      <?php elseif($obj['type_id_1'] == 4||$obj['type_id'] == 4): ?>
                      <i class="icon-cate-dm"></i>
                     <?php else: endif; if($obj['type_1']!=''): ?><?php echo $obj['type_1']['type_name']; else: ?><?php echo $obj['type']['type_name']; endif; ?>
                </span>
                </a>
                 
                <div class="tag-link">
				<span class="slash">/</span>    
				<?php $_62e29b9f8cbd4=explode(',',$obj['vod_class']); if(is_array($_62e29b9f8cbd4) || $_62e29b9f8cbd4 instanceof \think\Collection || $_62e29b9f8cbd4 instanceof \think\Paginator): if( count($_62e29b9f8cbd4)==0 ) : echo "" ;else: foreach($_62e29b9f8cbd4 as $key2=>$vo2): ?>	    
				<a href="<?php echo mac_url_type($obj['type']['type_id'],['id'=>$obj['type_id'],'class'=>$vo2],'show'); ?>"><?php echo $vo2; ?></a><span class="slash">/</span>
				<?php endforeach; endif; else: echo "" ;endif; ?>
				</div>
						
		    	<a class="tag-link" href="<?php echo mac_url_type($obj['type']['type_id'],['id'=>$obj['type_id'],'year'=>$obj['vod_year']],'show'); ?>"><?php echo mac_default($obj['vod_year'],'未知'); ?>	</a>
						
                <a class="tag-link" href="<?php echo mac_url_type($obj['type']['type_id'],['id'=>$obj['type_id'],'area'=>$obj['vod_area']],'show'); ?>"><?php echo mac_default($obj['vod_area'],'未知'); ?>	</a>
                        
                 </div>
            </div>
            <div class="video-info-main">
              <div class="video-info-items"><span class="video-info-itemtitle">剧情：</span>
                <div class="video-info-item video-info-content">
                <p class="zkjj_a" ><?php echo mac_substring($obj['vod_blurb'],150); ?><span class="zk_jj red">[展开全部]</span></p><p class="sqjj_a" style="display: none;">　<?php echo mac_filter_html($obj['vod_content']); ?><span class="sq_jj red">[收起部分]</span></p>
                </div>
              </div>
            </div>
          </div>
          <div class="video-player-handle">
              <?php if($obj['player_info']['link_next']): ?>
             <a href="<?php if($param['nid'] == $obj['vod_play_list'][$param['sid']]['url_count']): ?>javascript:void(0); <?php else: ?><?php echo $obj['player_info']['link_next']; endif; ?>" class="btn-block-o handle-btn" title="播放《<?php echo $obj['vod_name']; ?>》下一集"><i class="icon-next"></i><p class="block-name">下一集</p></a>
          
             <?php endif; ?>
            <div class="drop pc"><span class="btn-block-o handle-btn handle-more" title="拿起手机扫一扫"><i class="icon-qrcode"></i>
              <p class="block-name">手机看</p>
              </span>
              <div class="drop-content handle-more-drop">
                <div class="drop-content-box">
                  <div class="drop-content-items"><a class="btn-qrcode">
                    <div class="qrcode-img"></div>
                    <div class="block-name">
                      <p>使用 手机浏览器 扫码观看</p>
                      <strong><?php echo $obj['vod_name']; ?> -<?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?></strong></div>
                    </a></div>
                </div>
              </div>
              <div class="shortcuts-mobile-overlay"></div>
            </div>
            <?php if(!(empty($obj[vod_down_from]) || (($obj[vod_down_from] instanceof \think\Collection || $obj[vod_down_from] instanceof \think\Paginator ) && $obj[vod_down_from]->isEmpty()))): ?>
             <a href="<?php echo mac_url_vod_down($obj); ?>/#downlist" class="btn-block-o handle-btn handle-down" title="《<?php echo $obj['vod_name']; ?>》可免费下载"><i class="icon-download-bold"></i><em>免费</em><p class="block-name">可下载</p></a>
             <?php endif; ?>
            <div class="video-player-handle-more">
              <div class="btn-block-o handle-btn handle-share share-btn" title="分享《<?php echo $obj['vod_name']; ?>》给朋友一起看" data-clipboard-text="<?php echo $maccms['site_url']; ?><?php echo mac_url_vod_detail($obj); ?> 我正在<?php echo $maccms['site_name']; ?>观看《<?php echo $obj['vod_name']; ?>》，推荐给你一起看！"><i class="icon-share"></i>
                <p class="block-name">分享</p>
              </div>
              <div class="drop"><span class="btn-block-o handle-btn handle-more"><i class="icon-more"></i>
                <p class="block-name">观影+</p>
                </span>
                <div class="drop-content handle-more-drop">
                  <div class="drop-content-box">
                    <div class="drop-content-items"><a class="btn-block-o btn-report" href="javascript:;"><i class="icon-warn"></i>
                      <p class="block-name"><strong>影片报错</strong><br>
                        如遇无法播放请提交给我们</p>
                      </a><a class="btn-block-o btn-screen"><i class="icon-tv"></i>
                      <p class="block-name"><strong>投屏到电视</strong><br>
                        教程：把手机影片投到电视上播放</p>
                      </a></div>
                  </div>
                </div>
                <div class="shortcuts-mobile-overlay"></div>
              </div>
            </div>
          </div>
        </div>
	<!--AD3-->
		<?php if($dyxsst['dycms']['s3']['ad3'] == 1): ?>	
<div class="player-recommend recommend-list"><a href="<?php echo $dyxsst['dycms']['s3']['ad3_url']; ?>" target="_blank"><div class="pc"><img src="<?php echo mac_url_img($dyxsst['dycms']['s3']['ad3_pc']); ?>"></div><div class="phone"><img src="<?php echo mac_url_img($dyxsst['dycms']['s3']['ad3_wap']); ?>"></div></a></div>
	<?php endif; ?>
	<!---->            
      </div>
      
      <div class="player-box-side">
        <div class="module-heading">
          <h2 class="module-title" title="<?php echo $obj['vod_name']; ?>的在线观看列表">在线观看</h2>
          <div class="module-tab module-player-tab  player-side-tab">
            <input type="hidden" name="tab" id="tab" class="module-tab-input">
            <label class="module-tab-name"><span class="module-tab-value">切换节点</span><i class="icon-arrow-bottom-o"></i></label>
             <div class="module-tab-items">
              <div class="module-tab-title">播放节点列表<span class="close-drop"><i class="icon-close-o"></i></span></div>
            <div class="module-tab-content">
               <?php if(is_array($obj['vod_play_list']) || $obj['vod_play_list'] instanceof \think\Collection || $obj['vod_play_list'] instanceof \think\Paginator): if( count($obj['vod_play_list'])==0 ) : echo "" ;else: foreach($obj['vod_play_list'] as $key=>$vo): if($param['sid'] == $vo['sid']): ?> 
                 <div class="module-tab-item tab-item selected" data-dropdown-value="<?php echo $vo['player_info']['show']; ?>"><span><?php echo $vo['player_info']['show']; ?></span><small><?php echo $vo['url_count']; ?></small></div>
               <?php else: ?>    
               <a class="module-tab-item tab-item" href="<?php echo mac_url_vod_play($obj,['sid'=>$vo['sid'],'nid'=>$param['nid']]); ?>"><span data-dropdown-value="<?php echo $vo['player_info']['show']; ?>"><?php echo $vo['player_info']['show']; ?></span><small><?php echo $vo['url_count']; ?></small></a>
               <?php endif; endforeach; endif; else: echo "" ;endif; ?>	
                 </div>
            </div>
          </div>
          <div class="shortcuts-mobile-overlay"></div>
        </div>
        <?php if(is_array($obj['vod_play_list']) || $obj['vod_play_list'] instanceof \think\Collection || $obj['vod_play_list'] instanceof \think\Paginator): if( count($obj['vod_play_list'])==0 ) : echo "" ;else: foreach($obj['vod_play_list'] as $key=>$vo): ?>	
          <div class="module-list module-player-list tab-list sort-list <?php switch($obj['type_id_1']): case "3": ?>module-vod-list<?php break; endswitch; if($param['sid'] == $vo['sid']): ?> selected<?php endif; ?>   player-side-playlist">
          <div class="module-tab module-sorttab">
            <input type="hidden" name="tab-sort" id="tab-sort" class="module-tab-input">
            <label class="module-tab-name"><i class="icon-all"></i></label>
            <div class="module-tab-items">
              <div class="module-tab-title">选集<span class="close-drop"><i class="icon-close-o"></i></span><a class="desc sort-button" href="javascript:void(0);" to="#sort-item-<?php echo $key; ?>"><i class="icon-sort"></i>排序</a></div>
              <div class="module-tab-content">
                <div class="module-blocklist">
                  <div class="sort-item" id="sort-item-<?php echo $key; ?>">
                <?php if(is_array($vo['urls']) || $vo['urls'] instanceof \think\Collection || $vo['urls'] instanceof \think\Paginator): if( count($vo['urls'])==0 ) : echo "" ;else: foreach($vo['urls'] as $key2=>$vo2): ?> 
                <a href="<?php echo mac_url_vod_play($obj,['sid'=>$vo['sid'],'nid'=>$vo2['nid']]); ?>" class="<?php if($param['sid'] == $vo['sid'] && $param['nid'] == $vo2['nid']): ?>selected<?php endif; ?>"  title="播放<?php echo $obj['vod_name']; ?><?php echo $vo2['name']; ?>"><span><?php echo $vo2['name']; ?></span>
                  <?php if($param['sid'] == $vo['sid'] && $param['nid'] == $vo2['nid']): ?><div class="playon"><i></i><i></i><i></i><i></i></div><?php endif; ?>
                </a>
                <?php endforeach; endif; else: echo "" ;endif; ?>                     
                   </div>
                </div>
              </div>
            </div>
          </div>
          <div class="shortcuts-mobile-overlay"></div>
          <div class="module-blocklist scroll-box scroll-box-y">
            <div class="scroll-content">
               <?php if(is_array($vo['urls']) || $vo['urls'] instanceof \think\Collection || $vo['urls'] instanceof \think\Paginator): if( count($vo['urls'])==0 ) : echo "" ;else: foreach($vo['urls'] as $key2=>$vo2): ?> 
            <a href="<?php echo mac_url_vod_play($obj,['sid'=>$vo['sid'],'nid'=>$vo2['nid']]); ?>" class="<?php if($param['sid'] == $vo['sid'] && $param['nid'] == $vo2['nid']): ?>selected<?php endif; ?>" title="播放<?php echo $obj['vod_name']; ?><?php echo $vo2['name']; ?>"><span><?php echo $vo2['name']; ?></span>
              <?php if($param['sid'] == $vo['sid'] && $param['nid'] == $vo2['nid']): ?><div class="playon"><i></i><i></i><i></i><i></i></div><?php endif; ?>
            </a>
             <?php endforeach; endif; else: echo "" ;endif; ?>              
                          
            </div>
          </div>
        </div>
         <?php endforeach; endif; else: echo "" ;endif; ?>
              </div>
    </div>
  </div>
  <div class="content">
      
      	<div class="module">
			<div class="module-heading">
			<h2 class="module-title" title="与<?php echo $obj['vod_name']; ?>相关的影片列表">相关影片</h2>
			</div>
			<div class="module-list module-lines-list">
				<div class="module-items">
				<?php $__TAG__ = '{"num":"16","type":"current","order":"desc","by":"time","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>	
				                <div class="module-item">
				<div class="module-item-cover">
					<div class="module-item-pic">
						<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>" >
							<i class="icon-play"></i>
						</a>
						<img class="lazy lazyloaded"  data-src="<?php echo mac_url_img($vo['vod_pic']); ?>" src="<?php echo mac_url_img($dyxsst['dycms']['s1']['pic']); ?>"  alt="<?php echo $vo['vod_name']; ?>">
						<div class="loading"></div>
					</div>
					<div class="module-item-caption">
						<span><?php echo $vo['vod_year']; ?></span>
						<span class="video-class"><?php echo $vo['type']['type_name']; ?></span>
						<span><?php echo $vo['vod_area']; ?></span>
					</div>
					<div class="module-item-content">
						<div class="module-item-style video-name">
							<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
						</div>
						<div class="module-item-style video-tag">
						<?php echo mac_url_create(mac_default($vo['vod_actor'],'未知'),'actor'); ?>
						</div>
						<div class="module-item-style video-text"><?php echo $vo['vod_blurb']; ?></div>
					</div>
				</div>
				<div class="module-item-titlebox">
					<a href="<?php echo mac_url_vod_detail($vo); ?>" class="module-item-title" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
				</div>
				<div class="module-item-text"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></div>
			</div>
		        <?php endforeach; endif; else: echo "" ;endif; ?>
				</div>
			</div>
		</div>
		       <!-- 相关影片 -->
    
  	   <div class="module">
			<div class="module-heading">
				<h2 class="module-title">正在热播</h2>
				<a class="more" href="<?php echo mac_url_type($vo,[],'show'); ?>" title="更多">更多<i class="icon-arrow-right-o"></i></a>
			</div>
			<div class="module-list module-lines-list">
				<div class="module-items">
				<?php $__TAG__ = '{"num":"6","type":"all","order":"asc","by":"time","level":"8","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>	
				                <div class="module-item">
				<div class="module-item-cover">
					<div class="module-item-pic">
						<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>" >
							<i class="icon-play"></i>
						</a>
						<img class="lazy lazyloaded"  data-src="<?php echo mac_url_img($vo['vod_pic']); ?>" src="<?php echo mac_url_img($dyxsst['dycms']['s1']['pic']); ?>"  alt="<?php echo $vo['vod_name']; ?>">
						<div class="loading"></div>
					</div>
					<div class="module-item-caption">
						<span><?php echo $vo['vod_year']; ?></span>
						<span class="video-class"><?php echo $vo['type']['type_name']; ?></span>
						<span><?php echo $vo['vod_area']; ?></span>
					</div>
					<div class="module-item-content">
						<div class="module-item-style video-name">
							<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
						</div>
						<div class="module-item-style video-tag">
						<?php echo mac_url_create(mac_default($vo['vod_actor'],'未知'),'actor'); ?>
						</div>
						<div class="module-item-style video-text"><?php echo $vo['vod_blurb']; ?></div>
					</div>
				</div>
				<div class="module-item-titlebox">
					<a href="<?php echo mac_url_vod_detail($vo); ?>" class="module-item-title" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a>
				</div>
				<div class="module-item-text"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></div>
			</div>
		        <?php endforeach; endif; else: echo "" ;endif; ?>
				</div>
			</div>
		</div>       <!-- 正在热播 -->
 
  </div>
</main>

 <footer id="footer" class="wrapper">
	<p class="sitemap">
	    <?php if($dyxsst['dycms']['s2']['about'] == 1): ?>
		<a target="_blank" href="<?php echo mac_url('label/about'); ?>">关于</a><span class="space-line-bold"></span>
		<?php endif; ?>
		<a target="_blank" href="<?php echo mac_url('map/index'); ?>">MAP</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/index'); ?>">RSS</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/baidu'); ?>">Baidu</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/baidu'); ?>">Google</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/bing'); ?>">Bing</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/so'); ?>">so</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/sogou'); ?>">Sogou</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/sm'); ?>">SM</a>
	</p>
	<p><?php echo $dyxsst['dycms']['s1']['sm']; ?></p>
	<p class="none"><?php echo $maccms['site_tj']; ?></p>
</footer>



<div class="foot_right_bar">
	<div title="求片留言">
	<a  href="<?php echo mac_url('gbook/index'); ?>" >
	<i class="iconfont icon-liuyan"></i>
	</a>
	</div>
	<div class="goTop" title="返回顶部">
		<i class="iconfont icon-up"></i>
	</div>
</div>

<script type="text/javascript">
$(function(){	
	$(window).scroll(function() {		
		if($(window).scrollTop() >= 100){
			$('.goTop').fadeIn(300); 
		}else{    
			$('.goTop').fadeOut(300);    
		}  
	});
	$('.goTop').click(function(){
	$('html,body').animate({scrollTop: '0px'}, 800);});	
});
</script>

<?php if($dyxsst['dycms']['s2']['tc'] == 1): ?>

<div class="popup" id="note" style="display:none;">
	<div class="popup-icon"><img src="<?php echo $maccms['path_tpl']; ?>static/picture/backhome.svg"></div>
	<div class="popup-header">
		<h3 class="popup-title">公告内容</h3>
	</div>
	<div class="popup-main">
<?php echo $dyxsst['dycms']['s2']['tc_noti']; ?>
	</div>
	<div class="popup-footer"><span class="popup-btn" onclick="closeclick()">我记住啦</span></div>
</div>
<?php endif; ?>
<script src="<?php echo $maccms['path_tpl']; ?>static/js/tccookie.js"></script>
 <!-- 弹窗公告-->

   
<div class="popup popup-notice none">
	<div class="popup-icon"><img src="<?php echo $maccms['path_tpl']; ?>static/picture/backhome.svg"></div>
	<div class="popup-header">
		<h3 class="popup-title">域名列表</h3></div>
	<div class="popup-main">
		<p>本站有多个域名方便大家记住可以上哦!</p>
		<p>-
			<a><strong><?php echo $maccms['site_url']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web1']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web2']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web3']; ?></strong></a><br>
		</p>
	</div>
	<div class="popup-footer">
		<a href="<?php echo mac_url('label/web'); ?>" class="popup-btn-o">查看全部域名</a>
		<?php if($dyxsst['dycms']['s2']['about'] == 1): ?>
		<a href="<?php echo mac_url('label/about'); ?>" class="popup-btn-o">关于本站</a>
		<?php endif; ?>
	</div>
	<div class="close-popup" id="close-popup"><i class="icon-close-o"></i></div>
</div> <!-- 网址-->
         
<div class="shortcuts-mobile-overlay"></div>
 <!-- 底部-->
 
 <div class="shortcuts-box"><div id="shortcuts-info"></div></div>

 <div class="shortcuts-mobile-overlay"></div>

 <div class="popup popup-tips none" >
  <div class="popup-header">
    <h3 class="popup-title">投屏教程</h3>
  </div>
  <div class="popup-main">
    <p><strong>第一步</strong><br>
      将电视/盒子、手机连接到同一WIFI下；</p>
    <p><strong>第二步</strong><br>
      在视频播放页面，找到 <strong><i class="icon-screen-o"></i></strong> 图标，从列表中选择需要投屏的设备即可投屏成功；</p>
    <p><strong>依然无法连接到电视？</strong><br>
      请点击下方按钮，查看不同手机和浏览器的投屏教程。</p>
  </div>
  <div class="popup-footer"><a href="<?php echo mac_url('label/help'); ?>" target="_blank" class="popup-btn-o">查看详细教程</a></div>
  <div class="close-popup" id="close-popup"><i class="icon-close-o"></i></div>
</div>
       <!-- 投屏教程 -->
 
 <div class="shortcuts-mobile-overlay"></div>



<div class="popup popup-report none" id="report-popup">
  <div class="popup-icon"><img src="<?php echo $maccms['path_tpl']; ?>static/picture/report.svg"></div>
  <div class="popup-header">
    <h2 class="popup-title">我要报错</h2>
  </div>
  <div class="popup-main">
    <div class="report-box">
      <form class="gbook_form">
        <input type="hidden" name="gbook_rid" value="<?php echo $param['id']; ?>">
        <p>如遇影片无法播放，可能存在网络拥堵等情况，可尝试<strong>切换节点</strong>或<strong>刷新</strong>页面。</p>
        <p>尝试后以下影片仍无法播放：</p>
        <textarea class="report-content" name="gbook_content">
<?php echo $obj['vod_play_list'][$param['sid']]['player_info']['show']; ?>线路 - 《<?php echo $obj['vod_name']; ?>》
 <?php echo $maccms['site_url']; ?><?php echo mac_url_vod_play($obj,['sid'=>$param['sid'],'nid'=>$param['nid']]); ?></textarea>
      
             <p class="verify-box"><input class="report-content report-input" name="verify" type="text" autocomplete="off">
             <img class="report-verify" src="<?php echo mac_url('verify/index'); ?>" onClick="this.src+='?'" ></p>
          
                <input type="button" class="gbook_submit popup-btn" value="确认无误，提交">
      </form>
    </div>
  </div>
  <div class="close-popup"><i class="icon-close-o"></i></div>
</div>  

<div class="shortcuts-mobile-overlay"></div>
<span class="mac_ulog_set none" alt="设置播放页浏览记录" data-type="4" data-mid="<?php echo $maccms['mid']; ?>" data-id="<?php echo $obj['vod_id']; ?>" data-sid="<?php echo $param['sid']; ?>" data-nid="<?php echo $param['nid']; ?>"></span>
<span class="mac_hits none" data-mid="<?php echo $maccms['mid']; ?>" data-id="<?php echo $obj['vod_id']; ?>" data-type="hits"></span>
	<script>
		 $(".sq_jj").click(function(){
          $(".sqjj_a").toggle();
          $(".zkjj_a").toggle();
        });
      $(".zk_jj").click(function(){
          $(".sqjj_a").toggle();
          $(".zkjj_a").toggle();
      });
               if ($('.swiper-container').length > 0) {
    var mySwiper = new Swiper('.swiper-container', {
      direction: 'vertical',
      speed: 500,
      autoplay: {
        delay: 5000,
        stopOnLastSlide: false,
        disableOnInteraction: false,
      },
      loop: true
    });
  }
  </script>
 <?php if($dyxsst['dycms']['s2']['miniplay'] == 1): ?>
  <script>
 window.onload=function(){
 var ha = ($('.MacPlayer').find('table').offset().top + $('.MacPlayer').find('table').height());
 $(window).scroll(function(){ 
 if ( $(window).scrollTop() > ha ) { 
 $('.MacPlayer').find('table').removeClass('in').addClass('out');
 $('.MacPlayer').find('table').css('height','250px');
 $('.MacPlayer').find('table').css('width','450px');
 } else if ( $(window).scrollTop() < ha) { 
 $('.MacPlayer').find('table').removeClass('out').addClass('in'); 
 $('.MacPlayer').find('table').css('height','100%');
 } 
 });
}	  		</script>
<?php endif; ?>
</body>

</html>