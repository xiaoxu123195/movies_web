<?php if (!defined('THINK_PATH')) exit(); /*a:8:{s:35:"template/DYXS2/html/vod/search.html";i:1620142062;s:71:"/www/wwwroot/vip.lion888.eu.org/template/DYXS2/html/public/include.html";i:1622314980;s:71:"/www/wwwroot/vip.lion888.eu.org/template/DYXS2/html/vod/searchhead.html";i:1617459928;s:73:"/www/wwwroot/vip.lion888.eu.org/template/DYXS2/html/vod/searchvodbox.html";i:1620653854;s:70:"/www/wwwroot/vip.lion888.eu.org/template/DYXS2/html/public/paging.html";i:1620141904;s:68:"/www/wwwroot/vip.lion888.eu.org/template/DYXS2/html/public/foot.html";i:1621911972;s:72:"/www/wwwroot/vip.lion888.eu.org/template/DYXS2/html/public/tcnotice.html";i:1620625578;s:71:"/www/wwwroot/vip.lion888.eu.org/template/DYXS2/html/public/website.html";i:1621912062;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cn">
 <head>
     <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
     <title>搜索结果<?php echo $param['wd']; ?>-<?php echo $maccms['site_name']; ?></title>
     <meta name="keywords" content="<?php echo $param['wd']; ?>-<?php echo $maccms['site_name']; ?>" />
     <meta name="description" content="<?php echo $param['wd']; ?>-<?php echo $maccms['site_name']; ?>" />
     <?php $file = 'template/DYXS2/asset/admin/Dyxs2.php'; $newfile = 'application/admin/controller/Dyxs2.php'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $file = 'template/DYXS2/asset/admin/dyxsst.php'; $newfile = 'application/extra/dyxsst.php'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $file = 'template/DYXS2/asset/admin/dycms.html'; $newfile = 'application/admin/view/system/dycms.html'; if (file_exists($newfile)) {} else { copy($file,$newfile); } $dyxsst = file_exists('application/extra/dyxsst.php') ? require('application/extra/dyxsst.php') : require(substr($maccms['path_tpl'], strlen($maccms['path'])).'asset/admin/dyxsst.php'); ?>

<link rel="icon" href="<?php echo mac_url_img($dyxsst['dycms']['s1']['logo2']); ?>" type="image/png" />
<link href="<?php echo $maccms['path_tpl']; ?>static/css/style.css" rel="stylesheet" type="text/css">
<link href="<?php echo $maccms['path_tpl']; ?>static/css/ali.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo $maccms['path_tpl']; ?>static/css/swiper-bundle.min.css" type="text/css">
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.js"></script>
<script src="https://cdn.bootcdn.net/ajax/libs/layer/3.4.0/layer.min.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.lazyload.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.autocomplete.js"></script>
<script type="text/javascript" src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.cookie.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/home.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.clipboard.js"></script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/swiper-bundle.min.js"></script>
<?php if($maccms['aid'] == 15): ?>
<script type="text/javascript">var vod_name='<?php echo $obj['vod_name']; ?>',vod_url=window.location.href,vod_part='<?php echo $obj['vod_play_list'][$param['sid']]['urls'][$param['nid']]['name']; ?>';</script>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/history.js"></script>
 <script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/jquery.qrcode.min.js"></script>
<?php endif; ?>
<script type="text/javascript"  src="<?php echo $maccms['path_tpl']; ?>static/js/script.js"></script>

 </head>
<body class="search page">
<header id="header" class="wrapper">
  <div class="nav content">
     <div class="brand"><a href="<?php echo $maccms['path']; ?>" class="logo" title="<?php echo $maccms['site_name']; ?>"><img src="<?php echo $maccms['path_tpl']; ?>static/image/logo.png" alt="<?php echo $maccms['site_name']; ?>"></a></div>
    <div class="nav-search"></div>
    <nav class="nav-menu">
      <ul class="nav-menu-items">
      <li class="nav-menu-item <?php if($maccms['aid'] == 1): ?>selected<?php endif; ?>">
		<a href="<?php echo $maccms['path']; ?>" title="<?php echo $maccms['site_name']; ?>首页"><i class="icon-home"></i>首页</a>
	</li>
      <?php $__TAG__ = '{"order":"asc","by":"sort","ids":"parent","flag":"vod","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>			
	    <li class="nav-menu-item <?php if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?>selected<?php endif; ?>">
		<a class="nav-link" href="<?php echo mac_url_type($vo); ?>"><span class="nav-menu-item-name">
		    	            <?php if($vo['type_id'] == 1): ?>
	                        <i class="icon-cate-dy"></i>
	                        <?php elseif($vo['type_id'] == 2): ?>
	                        <i class="icon-cate-ds"></i>
	                        <?php elseif($vo['type_id'] == 4): ?>
	                        <i class="icon-cate-dm"></i>
	                        <?php else: ?>
	                        <i class="icon-cate-zy"></i>
	                        <?php endif; ?>
		    <?php echo $vo['type_name']; ?> </span> </a>
		</li>
		<?php endforeach; endif; else: echo "" ;endif; ?>	
		<li class="nav-menu-item domain"><span class="nav-menu-item-name"><i class="icon-domain"></i>网址</span><em>+</em></li>
				<li class="space-line-bold"></li>
				<li class="nav-menu-item">
				<a class="nav-menu-item-name"  href="<?php echo mac_url('label/app'); ?>" title="下载<?php echo $maccms['site_name']; ?>APP"><i class="icon-app"></i>APP</a>
				</li>
        <li class="nav-menu-item drop"><span class="nav-menu-icon"><i class="icon-all"></i></span>
          <div class="drop-content sub-block">
            <div class="drop-content-box grid-box">
              <ul class="drop-content-items grid-items">
                <li class="grid-item"><a href="<?php echo $maccms['path']; ?>"><i class="icon-home"></i>
                  <div class="grid-item-name" title="<?php echo $maccms['site_name']; ?>首页">首页</div>
                  </a></li>
                   <?php $__TAG__ = '{"order":"asc","by":"sort","ids":"parent","flag":"vod","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>			
					<li class="grid-item">
					<a href="<?php echo mac_url_type($vo); ?>" title="<?php echo $vo['type_name']; ?>">
					<i class="<?php switch($vo['type_id']): case "1": ?>icon-cate-dy<?php break; case "2": ?>icon-cate-ds<?php break; case "3": ?>icon-cate-zy<?php break; case "4": ?>icon-cate-dm<?php break; endswitch; ?>"></i>
					<div class="grid-item-name"><?php echo $vo['type_name']; ?></div>
					</a>
					</li>
					<?php endforeach; endif; else: echo "" ;endif; ?>	         
                    <li class="grid-item domain">
								<a href="javascript:;"><i class="icon-domain"></i>
								<div class="grid-item-name" title="网址">网址</div>
								</a>
								</li>
								<li class="grid-item grid-more">
									<a class="grid-more-link"  href="<?php echo mac_url_type($obj,['id'=>1],'show'); ?>" title="查看全部影片">
										<div class="grid-item-name">全部影片</div>
									</a>
								</li>
							    <li class="grid-item grid-more android">
								<a href="<?php echo mac_url('label/app'); ?>" class="grid-more-link" title="下载<?php echo $maccms['site_name']; ?>APP">
								<div class="grid-item-name">下载客户端</div>
								</a>
								</li>         
               </ul>
            </div>
          </div>
          <div class="shortcuts-mobile-overlay"></div>
        </li>
        <li class="space-line-bold"></li>
        <li class="nav-menu-item drop"><span class="nav-menu-icon"><i class="icon-watch-history"></i></span>
          <div class="drop-content drop-history">
            <div class="drop-content-box">
              <ul class="drop-content-items" id="history"><li class="list-item list-item-title"><a href="" class="playlist historyclean"><i class="icon-clear"></i></a><strong>我的观影记录</strong></li></ul>
            </div>
          </div>
          <div class="shortcuts-mobile-overlay"></div>
        </li>
      </ul>
    </nav>
  </div>
</header> <!-- 头部 -->
<main id="main" class="wrapper">
  <div class="content">
    <div id="search-content">
    <form action="<?php echo mac_url('vod/search'); ?>">
				<div class="search-box">
					<input class="search-input ac_wd" id="txtKeywords" type="text" name="wd" autocomplete="off" placeholder="搜索电影、电视剧、综艺、动漫">
					<div class="search-drop">
						<div class="drop-content-items ac_hot none">
							<div class="list-item list-item-title"><strong>大家都在搜这些影片</strong></div>
							<div class="search-tag">
							<?php $_62e4b5e45d46f=explode(',',$maccms['search_hot']); if(is_array($_62e4b5e45d46f) || $_62e4b5e45d46f instanceof \think\Collection || $_62e4b5e45d46f instanceof \think\Paginator): if( count($_62e4b5e45d46f)==0 ) : echo "" ;else: foreach($_62e4b5e45d46f as $key2=>$vo2): ?>
					       	<a href="<?php echo mac_url('vod/search',['wd'=>$vo2]); ?>" class="<?php if($key2 < 4): ?>hot <?php else: endif; ?>"><i class="icon-hot"></i><?php echo $vo2; ?></a>
						    <?php endforeach; endif; else: echo "" ;endif; ?>
							</div>
						</div>
					</div>
					<button class="search-btn search-go" type="submit"><i class="icon-search"></i></button>
					<button class="cancel-btn" type="button">取消</button>
				</div>
			</form>
      <div class="search-stat">
        <h1><?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?></h1>
        <h2>搜索"<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?>" ，找到 <strong class="mac_total"></strong>部影视作品</h2>
      </div>
    </div>
    <div class="module">
      <div class="module-list">
        <div class="module-items">
            <?php $__TAG__ = '{"num":"10","paging":"yes","pageurl":"vod\/search","order":"desc","by":"time","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__);$__PAGING__ = mac_page_param($__LIST__['total'],$__LIST__['limit'],$__LIST__['page'],$__LIST__['pageurl'],$__LIST__['half']); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?> 
                   <div class="module-search-item">
            <div class="video-cover">
              <div class="module-item-cover">
                <div class="module-item-pic"><a href="<?php echo mac_url_vod_play($vo); ?>" title="立刻播放<?php echo $vo['vod_name']; ?>"><i class="icon-play"></i></a><img class="lazy lazyload" data-src="<?php echo mac_url_img($vo['vod_pic']); ?>" src="<?php echo mac_url_img($dyxsst['dycms']['s1']['pic']); ?>" alt="<?php echo $vo['vod_name']; ?>">
                  <div class="loading"></div>
                </div>
              </div>
            </div>
            <div class="video-info">
              <div class="video-info-header"><a class="video-serial" href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></a>
                <h3><a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a></h3>
                <div class="video-info-aux">
                <a href="<?php if($vo['type_1']!=''): ?><?php echo mac_url_type($vo['type_1']); else: ?><?php echo mac_url_type($vo['type']); endif; ?>" title="<?php if($vo['type_1']!=''): ?><?php echo $vo['type_1']['type_name']; else: ?><?php echo $vo['type']['type_name']; endif; ?>" class="tag-link"><span class="video-tag-icon">
                    <?php if($vo['type_id_1'] == 1||$vo['type_id'] == 1): ?>
                    <i class="icon-cate-dy"></i>
                    <?php elseif($vo['type_id_1'] == 2||$vo['type_id'] == 2): ?>
                     <i class="icon-cate-ds"></i>
                      <?php elseif($vo['type_id_1'] == 3||$vo['type_id'] == 3): ?>
                      <i class="icon-cate-zy"></i>
                        <?php elseif($vo['type_id_1'] == 4||$vo['type_id'] == 4): ?>
                     <i class="icon-cate-dm"></i>
                    <?php else: endif; if($vo['type_1']!=''): ?><?php echo $vo['type_1']['type_name']; else: ?><?php echo $vo['type']['type_name']; endif; ?></span></a>
                	<div class="tag-link"><?php echo mac_url_create($vo['vod_year'],'year','vod','search'); ?></div>
                  <div class="tag-link"><?php echo mac_url_create($vo['vod_area'],'area','vod','search'); ?></div>
                 </div>
              </div>
              <div class="video-info-main">
                  <div class="video-info-items"><span class="video-info-itemtitle">导演：</span>
                 	<div class="video-info-item video-info-actor"><span class="slash">/</span>
					    <?php echo mac_url_create(mac_default($vo['vod_director'],'未知'),'director','vod','search','<span class="slash">/</span>'); ?>
						</div>
                </div>
                <div class="video-info-items"><span class="video-info-itemtitle">主演：</span>
                 <div class="video-info-item video-info-actor"><span class="slash">/</span>
						<?php echo mac_url_create(mac_default($vo['vod_actor'],'未知'),'actor','vod','search','<span class="slash">/</span>'); ?>
						</div>
                </div>
                  <div class="video-info-items"><span class="video-info-itemtitle">剧情：</span>
                  <div class="video-info-item"><?php echo $vo['vod_blurb']; ?></div>
                </div>
              </div>
              <div class="video-info-footer">
                 <a href="<?php echo mac_url_vod_play($vo); ?>" class="btn-important btn-base" title="立刻播放<?php echo $vo['vod_name']; ?>"><i class="icon-play"></i><strong>立即播放</strong></a>
              <?php if(!(empty($vo[vod_down_from]) || (($vo[vod_down_from] instanceof \think\Collection || $vo[vod_down_from] instanceof \think\Paginator ) && $vo[vod_down_from]->isEmpty()))): ?>
                 <a href="<?php echo mac_url_vod_detail($vo); ?>" class="btn-aux btn-aux-o btn-base" title="下载<?php echo $vo['vod_name']; ?>"><i class="icon-download"></i><strong>下载</strong></a>
               	<?php endif; ?>
              </div>
            </div>
          </div>  
            <?php endforeach; endif; else: echo "" ;endif; ?> 
            </div>
            <?php if($__PAGING__['page_total'] > 1): ?>
<div class="module-footer">
      <div id="page">
        <a href="<?php echo mac_url_page($__PAGING__['page_url'],1); ?>" class="page-number page-previous" title="首页">首页</a>
        <a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_prev']); ?>" class="page-number page-previous" title="上一页">上一页</a>
        <?php if(is_array($__PAGING__['page_num']) || $__PAGING__['page_num'] instanceof \think\Collection || $__PAGING__['page_num'] instanceof \think\Paginator): if( count($__PAGING__['page_num'])==0 ) : echo "" ;else: foreach($__PAGING__['page_num'] as $key=>$num): if($__PAGING__['page_current'] == $num): ?>
        <span class="page-number page-current display"><?php echo $num; ?></span>
        <?php else: ?>
          <a href="<?php echo mac_url_page($__PAGING__['page_url'],$num); ?>" class="page-number display" title="第<?php echo $num; ?>页"><?php echo $num; ?></a>
            <?php endif; endforeach; endif; else: echo "" ;endif; ?>
           <a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_next']); ?>" class="page-number page-next" title="下一页">下一页</a>
        <a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_total']); ?>" class="page-number page-next" title="尾页">尾页</a>
      </div>
    </div>
<?php endif; ?>  <!-- 分页 -->
        
             </div>
         </div>
      </div>
</main>
    <footer id="footer" class="wrapper">
	<p class="sitemap">
	    <?php if($dyxsst['dycms']['s2']['about'] == 1): ?>
		<a target="_blank" href="<?php echo mac_url('label/about'); ?>">关于</a><span class="space-line-bold"></span>
		<?php endif; ?>
		<a target="_blank" href="<?php echo mac_url('map/index'); ?>">MAP</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/index'); ?>">RSS</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/baidu'); ?>">Baidu</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/baidu'); ?>">Google</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/bing'); ?>">Bing</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/so'); ?>">so</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/sogou'); ?>">Sogou</a><span class="space-line-bold"></span>
		<a target="_blank" href="<?php echo mac_url('rss/sm'); ?>">SM</a>
	</p>
	<p><?php echo $dyxsst['dycms']['s1']['sm']; ?></p>
	<p class="none"><?php echo $maccms['site_tj']; ?></p>
</footer>



<div class="foot_right_bar">
	<div title="求片留言">
	<a  href="<?php echo mac_url('gbook/index'); ?>" >
	<i class="iconfont icon-liuyan"></i>
	</a>
	</div>
	<div class="goTop" title="返回顶部">
		<i class="iconfont icon-up"></i>
	</div>
</div>

<script type="text/javascript">
$(function(){	
	$(window).scroll(function() {		
		if($(window).scrollTop() >= 100){
			$('.goTop').fadeIn(300); 
		}else{    
			$('.goTop').fadeOut(300);    
		}  
	});
	$('.goTop').click(function(){
	$('html,body').animate({scrollTop: '0px'}, 800);});	
});
</script>

<?php if($dyxsst['dycms']['s2']['tc'] == 1): ?>

<div class="popup" id="note" style="display:none;">
	<div class="popup-icon"><img src="<?php echo $maccms['path_tpl']; ?>static/picture/backhome.svg"></div>
	<div class="popup-header">
		<h3 class="popup-title">公告内容</h3>
	</div>
	<div class="popup-main">
<?php echo $dyxsst['dycms']['s2']['tc_noti']; ?>
	</div>
	<div class="popup-footer"><span class="popup-btn" onclick="closeclick()">我记住啦</span></div>
</div>
<?php endif; ?>
<script src="<?php echo $maccms['path_tpl']; ?>static/js/tccookie.js"></script>
 <!-- 弹窗公告-->

   
<div class="popup popup-notice none">
	<div class="popup-icon"><img src="<?php echo $maccms['path_tpl']; ?>static/picture/backhome.svg"></div>
	<div class="popup-header">
		<h3 class="popup-title">域名列表</h3></div>
	<div class="popup-main">
		<p>本站有多个域名方便大家记住可以上哦!</p>
		<p>-
			<a><strong><?php echo $maccms['site_url']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web1']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web2']; ?></strong></a><br>-
			<a><strong><?php echo $dyxsst['dycms']['s2']['web3']; ?></strong></a><br>
		</p>
	</div>
	<div class="popup-footer">
		<a href="<?php echo mac_url('label/web'); ?>" class="popup-btn-o">查看全部域名</a>
		<?php if($dyxsst['dycms']['s2']['about'] == 1): ?>
		<a href="<?php echo mac_url('label/about'); ?>" class="popup-btn-o">关于本站</a>
		<?php endif; ?>
	</div>
	<div class="close-popup" id="close-popup"><i class="icon-close-o"></i></div>
</div> <!-- 网址-->
         
<div class="shortcuts-mobile-overlay"></div>
 <!-- 底部-->
<script>
  $(".mac_total").text('<?php echo $__PAGING__['record_total']; ?>');
</script>
 </body>
</html>