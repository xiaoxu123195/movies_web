<?php
//000000000600
 exit();?>
s:234:"/api.php/collect/api.html?ac=cj&cjflag=3a4e1c6f613d66b5836bcbf23ce4c695&cjurl=http%3A%2F%2Fwww.zycaiji.net%3A7788%2Fapi.php%2Fprovide%2Fvod%2F%3Fac%3Dlist&h=24&t=&ids=&wd=&type=2&mid=1&opt=0&sync_pic_opt=0&filter=0&filter_from=&param=";